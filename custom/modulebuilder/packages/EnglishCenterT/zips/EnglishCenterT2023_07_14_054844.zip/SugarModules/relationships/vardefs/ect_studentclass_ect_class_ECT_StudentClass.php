<?php
// created: 2023-07-14 05:45:37
$dictionary["ECT_StudentClass"]["fields"]["ect_studentclass_ect_class"] = array (
  'name' => 'ect_studentclass_ect_class',
  'type' => 'link',
  'relationship' => 'ect_studentclass_ect_class',
  'source' => 'non-db',
  'module' => 'ECT_Class',
  'bean_name' => 'ECT_Class',
  'side' => 'right',
  'vname' => 'LBL_ECT_STUDENTCLASS_ECT_CLASS_FROM_ECT_CLASS_TITLE',
);
