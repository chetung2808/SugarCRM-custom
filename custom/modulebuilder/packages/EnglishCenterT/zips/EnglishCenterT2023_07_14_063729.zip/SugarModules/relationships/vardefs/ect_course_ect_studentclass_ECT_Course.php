<?php
// created: 2023-07-14 06:37:28
$dictionary["ECT_Course"]["fields"]["ect_course_ect_studentclass"] = array (
  'name' => 'ect_course_ect_studentclass',
  'type' => 'link',
  'relationship' => 'ect_course_ect_studentclass',
  'source' => 'non-db',
  'module' => 'ECT_StudentClass',
  'bean_name' => 'ECT_StudentClass',
  'side' => 'right',
  'vname' => 'LBL_ECT_COURSE_ECT_STUDENTCLASS_FROM_ECT_STUDENTCLASS_TITLE',
);
