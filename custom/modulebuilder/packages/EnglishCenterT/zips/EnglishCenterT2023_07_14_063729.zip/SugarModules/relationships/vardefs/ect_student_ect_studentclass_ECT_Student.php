<?php
// created: 2023-07-14 06:37:29
$dictionary["ECT_Student"]["fields"]["ect_student_ect_studentclass"] = array (
  'name' => 'ect_student_ect_studentclass',
  'type' => 'link',
  'relationship' => 'ect_student_ect_studentclass',
  'source' => 'non-db',
  'module' => 'ECT_StudentClass',
  'bean_name' => 'ECT_StudentClass',
  'side' => 'right',
  'vname' => 'LBL_ECT_STUDENT_ECT_STUDENTCLASS_FROM_ECT_STUDENTCLASS_TITLE',
);
