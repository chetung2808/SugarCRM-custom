<?php
// created: 2023-07-14 06:37:27
$dictionary["ECT_StudentClass"]["fields"]["ect_class_ect_studentclass"] = array (
  'name' => 'ect_class_ect_studentclass',
  'type' => 'link',
  'relationship' => 'ect_class_ect_studentclass',
  'source' => 'non-db',
  'module' => 'ECT_Class',
  'bean_name' => 'ECT_Class',
  'vname' => 'LBL_ECT_CLASS_ECT_STUDENTCLASS_FROM_ECT_CLASS_TITLE',
  'id_name' => 'ect_class_ect_studentclassect_class_ida',
);
$dictionary["ECT_StudentClass"]["fields"]["ect_class_ect_studentclass_name"] = array (
  'name' => 'ect_class_ect_studentclass_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ECT_CLASS_ECT_STUDENTCLASS_FROM_ECT_CLASS_TITLE',
  'save' => true,
  'id_name' => 'ect_class_ect_studentclassect_class_ida',
  'link' => 'ect_class_ect_studentclass',
  'table' => 'ect_class',
  'module' => 'ECT_Class',
  'rname' => 'name',
);
$dictionary["ECT_StudentClass"]["fields"]["ect_class_ect_studentclassect_class_ida"] = array (
  'name' => 'ect_class_ect_studentclassect_class_ida',
  'type' => 'link',
  'relationship' => 'ect_class_ect_studentclass',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_ECT_CLASS_ECT_STUDENTCLASS_FROM_ECT_STUDENTCLASS_TITLE',
);
