<?php
 // created: 2023-07-14 05:45:36
$layout_defs["ECT_Course"]["subpanel_setup"]['ect_course_ect_class'] = array (
  'order' => 100,
  'module' => 'ECT_Class',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ECT_COURSE_ECT_CLASS_FROM_ECT_CLASS_TITLE',
  'get_subpanel_data' => 'ect_course_ect_class',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
