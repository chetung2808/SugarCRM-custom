<?php
// created: 2023-07-17 09:53:09
$dictionary["ECT_Class"]["fields"]["ect_studentclass_ect_class"] = array (
  'name' => 'ect_studentclass_ect_class',
  'type' => 'link',
  'relationship' => 'ect_studentclass_ect_class',
  'source' => 'non-db',
  'module' => 'ECT_StudentClass',
  'bean_name' => 'ECT_StudentClass',
  'vname' => 'LBL_ECT_STUDENTCLASS_ECT_CLASS_FROM_ECT_STUDENTCLASS_TITLE',
);
