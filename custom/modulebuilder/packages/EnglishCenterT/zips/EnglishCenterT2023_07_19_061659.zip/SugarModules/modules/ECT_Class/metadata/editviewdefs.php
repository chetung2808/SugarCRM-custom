<?php
$module_name = 'ECT_Class';
$viewdefs [$module_name] = 
array (
  'EditView' => 
  array (
    'templateMeta' => 
    array (
      'maxColumns' => '2',
      'widths' => 
      array (
        0 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
        1 => 
        array (
          'label' => '10',
          'field' => '30',
        ),
      ),
    ),
    'panels' => 
    array (
      'default' => 
      array (
        0 => 
        array (
          0 => 'name',
          1 => 'assigned_user_name',
        ),
        1 => 
        array (
          0 => 'description',
          1 => 
          array (
            'name' => 'ect_course_ect_class_name',
          ),
        ),
        2 => 
        array (
          0 => 
          array (
            'name' => 'ect_studentclass_ect_class_name',
          ),
        ),
      ),
    ),
  ),
);
?>
