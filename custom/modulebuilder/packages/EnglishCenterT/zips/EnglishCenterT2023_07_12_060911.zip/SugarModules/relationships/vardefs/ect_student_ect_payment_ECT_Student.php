<?php
// created: 2023-07-12 06:09:11
$dictionary["ECT_Student"]["fields"]["ect_student_ect_payment"] = array (
  'name' => 'ect_student_ect_payment',
  'type' => 'link',
  'relationship' => 'ect_student_ect_payment',
  'source' => 'non-db',
  'module' => 'ECT_Payment',
  'bean_name' => 'ECT_Payment',
  'side' => 'right',
  'vname' => 'LBL_ECT_STUDENT_ECT_PAYMENT_FROM_ECT_PAYMENT_TITLE',
);
