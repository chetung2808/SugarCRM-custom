<?php
 // created: 2023-07-11 12:25:19
$layout_defs["ECT_Student"]["subpanel_setup"]['ect_student_ect_payment'] = array (
  'order' => 100,
  'module' => 'ECT_Payment',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_ECT_STUDENT_ECT_PAYMENT_FROM_ECT_PAYMENT_TITLE',
  'get_subpanel_data' => 'ect_student_ect_payment',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
