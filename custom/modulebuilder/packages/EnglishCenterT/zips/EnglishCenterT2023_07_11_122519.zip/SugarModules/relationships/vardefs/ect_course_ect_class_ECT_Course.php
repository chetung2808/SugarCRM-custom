<?php
// created: 2023-07-11 12:25:18
$dictionary["ECT_Course"]["fields"]["ect_course_ect_class"] = array (
  'name' => 'ect_course_ect_class',
  'type' => 'link',
  'relationship' => 'ect_course_ect_class',
  'source' => 'non-db',
  'module' => 'ECT_Class',
  'bean_name' => 'ECT_Class',
  'side' => 'right',
  'vname' => 'LBL_ECT_COURSE_ECT_CLASS_FROM_ECT_CLASS_TITLE',
);
