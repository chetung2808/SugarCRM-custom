<?php
// created: 2023-07-17 09:55:40
$dictionary["ECT_StudentClass"]["fields"]["ect_studentclass_ect_class"] = array (
  'name' => 'ect_studentclass_ect_class',
  'type' => 'link',
  'relationship' => 'ect_studentclass_ect_class',
  'source' => 'non-db',
  'module' => 'ECT_Class',
  'bean_name' => 'ECT_Class',
  'vname' => 'LBL_ECT_STUDENTCLASS_ECT_CLASS_FROM_ECT_CLASS_TITLE',
);
