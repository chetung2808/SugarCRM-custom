<?php
// created: 2023-07-17 09:55:40
$dictionary["ECT_StudentClass"]["fields"]["ect_studentclass_ect_course"] = array (
  'name' => 'ect_studentclass_ect_course',
  'type' => 'link',
  'relationship' => 'ect_studentclass_ect_course',
  'source' => 'non-db',
  'module' => 'ECT_Course',
  'bean_name' => 'ECT_Course',
  'vname' => 'LBL_ECT_STUDENTCLASS_ECT_COURSE_FROM_ECT_COURSE_TITLE',
);
