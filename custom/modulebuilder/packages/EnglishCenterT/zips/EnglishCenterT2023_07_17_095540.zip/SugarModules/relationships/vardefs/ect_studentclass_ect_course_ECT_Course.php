<?php
// created: 2023-07-17 09:55:40
$dictionary["ECT_Course"]["fields"]["ect_studentclass_ect_course"] = array (
  'name' => 'ect_studentclass_ect_course',
  'type' => 'link',
  'relationship' => 'ect_studentclass_ect_course',
  'source' => 'non-db',
  'module' => 'ECT_StudentClass',
  'bean_name' => 'ECT_StudentClass',
  'vname' => 'LBL_ECT_STUDENTCLASS_ECT_COURSE_FROM_ECT_STUDENTCLASS_TITLE',
);
