<?php
// created: 2023-07-11 10:22:29
$dictionary["ECT_Lecturer"]["fields"]["ect_lecturer_ect_course"] = array (
  'name' => 'ect_lecturer_ect_course',
  'type' => 'link',
  'relationship' => 'ect_lecturer_ect_course',
  'source' => 'non-db',
  'module' => 'ECT_Course',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_ECT_LECTURER_ECT_COURSE_FROM_ECT_COURSE_TITLE',
);
