<?php
// created: 2023-07-17 09:42:35
$dictionary["ECT_StudentClass"]["fields"]["ect_class_ect_studentclass"] = array (
  'name' => 'ect_class_ect_studentclass',
  'type' => 'link',
  'relationship' => 'ect_class_ect_studentclass',
  'source' => 'non-db',
  'module' => 'ECT_Class',
  'bean_name' => 'ECT_Class',
  'vname' => 'LBL_ECT_CLASS_ECT_STUDENTCLASS_FROM_ECT_CLASS_TITLE',
);
