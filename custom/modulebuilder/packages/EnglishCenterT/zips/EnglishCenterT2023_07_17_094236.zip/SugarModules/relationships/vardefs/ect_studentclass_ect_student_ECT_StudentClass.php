<?php
// created: 2023-07-14 05:45:37
$dictionary["ECT_StudentClass"]["fields"]["ect_studentclass_ect_student"] = array (
  'name' => 'ect_studentclass_ect_student',
  'type' => 'link',
  'relationship' => 'ect_studentclass_ect_student',
  'source' => 'non-db',
  'module' => 'ECT_Student',
  'bean_name' => 'ECT_Student',
  'side' => 'right',
  'vname' => 'LBL_ECT_STUDENTCLASS_ECT_STUDENT_FROM_ECT_STUDENT_TITLE',
);
