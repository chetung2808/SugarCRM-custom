<?php
// created: 2023-07-17 09:53:09
$dictionary["ECT_StudentClass"]["fields"]["ect_student_ect_studentclass"] = array (
  'name' => 'ect_student_ect_studentclass',
  'type' => 'link',
  'relationship' => 'ect_student_ect_studentclass',
  'source' => 'non-db',
  'module' => 'ECT_Student',
  'bean_name' => 'ECT_Student',
  'vname' => 'LBL_ECT_STUDENT_ECT_STUDENTCLASS_FROM_ECT_STUDENT_TITLE',
);
