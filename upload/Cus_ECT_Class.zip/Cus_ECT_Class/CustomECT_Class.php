<?php

require_once('modules/Cus_ECT_Class/Cus_ECT_Class.php');

class CustomECT_Class extends ECT_Class
{
    public function __construct()
    {
        parent::__construct();
        $this->disable_row_level_security = true;
    }
}
