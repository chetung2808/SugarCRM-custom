<?php

$mod_strings['LBL_CUSTOM_XEP_LOP'] = 'Xếp Lớp';
