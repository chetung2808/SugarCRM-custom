<?php

$dictionary['Cus_ECT_Class']['view']['view.custom_xep_lop'] = array(
    'templateFile' => 'custom/modules/Cus_ECT_Class/views/view.custom_xep_lop.php',
    'title' => 'LBL_CUSTOM_XEP_LOP',
    'headerTpl' => 'modules/Cus_ECT_Class/views/templates/view.custom_xep_lop_header.tpl',
    'footerTpl' => 'modules/Cus_ECT_Class/views/templates/view.custom_xep_lop_footer.tpl',
    'module' => 'Cus_ECT_Class',
);
