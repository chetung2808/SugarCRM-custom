<?php
// created: 2023-07-11 09:51:42
$modules_sources = array (
  'Accounts' => 
  array (
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
  'Contacts' => 
  array (
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
  'Leads' => 
  array (
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
  'Prospects' => 
  array (
  ),
  'Opportunities' => 
  array (
    'ext_rest_insideview' => 'ext_rest_insideview',
  ),
);