<?php

$hook_version = 1;

$hook_array = array();

$hook_array['after_save'] = array();
$hook_array['after_save'][] = array(
    1,
    'ECT_Class',
    'custom/modules/ECT_Class/AssignClassID.php',
    'AssignClassID',
    'generateAndAssignCode'
);

$hook_array['before_save'] = array();
$hook_array['before_save'][] = array(
    1,
    'UpdateClassPayment',
    'custom/modules/ECT_Class/UpdateClassPayment.php',
    'UpdateClassPayment',
    'updatePayment'
);

