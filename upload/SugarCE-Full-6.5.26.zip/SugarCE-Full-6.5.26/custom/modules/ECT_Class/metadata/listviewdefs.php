<?php
$module_name = 'ECT_Class';
$listViewDefs [$module_name] = 
array (
  'ECT_COURSE_ECT_CLASS_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_ECT_COURSE_ECT_CLASS_FROM_ECT_COURSE_TITLE',
    'id' => 'ECT_COURSE_ECT_CLASSECT_COURSE_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'CLASS_ID' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CLASS_ID',
    'width' => '10%',
    'default' => true,
  ),
  'CLASS_NUMBEROFSTUDENTS' => 
  array (
    'type' => 'int',
    'label' => 'LBL_CLASS_NUMBEROFSTUDENTS',
    'width' => '10%',
    'default' => true,
  ),
  'CLASS_STARTDATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_CLASS_STARTDATE',
    'width' => '10%',
    'default' => true,
  ),
);
?>
