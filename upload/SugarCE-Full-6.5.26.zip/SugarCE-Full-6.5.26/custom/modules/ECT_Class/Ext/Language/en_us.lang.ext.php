<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_ECT_CLASS_ECT_STUDENT_FROM_ECT_STUDENT_TITLE'] = 'Student';
$mod_strings['LBL_ECT_COURSE_ECT_CLASS_FROM_ECT_COURSE_TITLE'] = 'Course';

?>