<?php
// created: 2023-07-11 10:25:36
$mod_strings = array (
  'LBL_ECT_CLASS_ECT_STUDENT_FROM_ECT_STUDENT_TITLE' => 'Student',
);