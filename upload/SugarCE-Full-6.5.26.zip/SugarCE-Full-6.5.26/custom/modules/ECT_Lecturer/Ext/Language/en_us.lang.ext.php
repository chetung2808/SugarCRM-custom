<?php 
 //WARNING: The contents of this file are auto-generated


//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_ECT_COURSE_ECT_LECTURER_FROM_ECT_COURSE_TITLE'] = 'Course';
$mod_strings['LBL_ECT_LECTURER_ECT_COURSE_FROM_ECT_COURSE_TITLE'] = 'Course';

?>