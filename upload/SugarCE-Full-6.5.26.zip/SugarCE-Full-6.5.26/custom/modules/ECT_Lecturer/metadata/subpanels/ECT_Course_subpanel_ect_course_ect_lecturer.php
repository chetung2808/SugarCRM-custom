<?php
// created: 2023-07-11 10:28:11
$subpanel_layout['list_fields'] = array (
  'name' => 
  array (
    'vname' => 'LBL_NAME',
    'widget_class' => 'SubPanelDetailViewLink',
    'width' => '45%',
    'default' => true,
  ),
  'ect_course_ect_lecturer_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'vname' => 'LBL_ECT_COURSE_ECT_LECTURER_FROM_ECT_COURSE_TITLE',
    'id' => 'ECT_COURSE_ECT_LECTURERECT_COURSE_IDA',
    'width' => '10%',
    'default' => true,
    'widget_class' => 'SubPanelDetailViewLink',
    'target_module' => 'ECT_Course',
    'target_record_key' => 'ect_course_ect_lecturerect_course_ida',
  ),
  'lecturer_id' => 
  array (
    'type' => 'varchar',
    'vname' => 'LBL_LECTURER_ID',
    'width' => '10%',
    'default' => true,
  ),
  'lecture_joinday' => 
  array (
    'type' => 'date',
    'vname' => 'LBL_LECTURE_JOINDAY',
    'width' => '10%',
    'default' => true,
  ),
  'date_modified' => 
  array (
    'vname' => 'LBL_DATE_MODIFIED',
    'width' => '45%',
    'default' => true,
  ),
  'edit_button' => 
  array (
    'vname' => 'LBL_EDIT_BUTTON',
    'widget_class' => 'SubPanelEditButton',
    'module' => 'ECT_Lecturer',
    'width' => '4%',
    'default' => true,
  ),
  'remove_button' => 
  array (
    'vname' => 'LBL_REMOVE',
    'widget_class' => 'SubPanelRemoveButton',
    'module' => 'ECT_Lecturer',
    'width' => '5%',
    'default' => true,
  ),
);