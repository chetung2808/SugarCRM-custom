<?php
// created: 2023-07-11 10:28:11
$mod_strings = array (
  'LBL_ECT_COURSE_ECT_CLASS_FROM_ECT_CLASS_TITLE' => 'Class',
  'LBL_ECT_COURSE_ECT_LECTURER_FROM_ECT_LECTURER_TITLE' => 'Lecturer',
);