<?php 
 //WARNING: The contents of this file are auto-generated


// created: 2023-07-11 12:36:52
$dictionary["ECT_Course"]["fields"]["ect_course_ect_class"] = array (
  'name' => 'ect_course_ect_class',
  'type' => 'link',
  'relationship' => 'ect_course_ect_class',
  'source' => 'non-db',
  'module' => 'ECT_Class',
  'bean_name' => 'ECT_Class',
  'side' => 'right',
  'vname' => 'LBL_ECT_COURSE_ECT_CLASS_FROM_ECT_CLASS_TITLE',
);


// created: 2023-07-11 12:36:52
$dictionary["ECT_Course"]["fields"]["ect_course_ect_lecturer"] = array (
  'name' => 'ect_course_ect_lecturer',
  'type' => 'link',
  'relationship' => 'ect_course_ect_lecturer',
  'source' => 'non-db',
  'module' => 'ECT_Lecturer',
  'bean_name' => 'ECT_Lecturer',
  'side' => 'right',
  'vname' => 'LBL_ECT_COURSE_ECT_LECTURER_FROM_ECT_LECTURER_TITLE',
);


// created: 2023-07-11 12:14:47
$dictionary["ECT_Course"]["fields"]["ect_course_ect_student_1"] = array (
  'name' => 'ect_course_ect_student_1',
  'type' => 'link',
  'relationship' => 'ect_course_ect_student_1',
  'source' => 'non-db',
  'module' => 'ECT_Student',
  'bean_name' => 'ECT_Student',
  'side' => 'right',
  'vname' => 'LBL_ECT_COURSE_ECT_STUDENT_1_FROM_ECT_STUDENT_TITLE',
);


// created: 2023-07-11 12:36:52
$dictionary["ECT_Course"]["fields"]["ect_lecturer_ect_course"] = array (
  'name' => 'ect_lecturer_ect_course',
  'type' => 'link',
  'relationship' => 'ect_lecturer_ect_course',
  'source' => 'non-db',
  'module' => 'ECT_Lecturer',
  'bean_name' => 'ECT_Lecturer',
  'vname' => 'LBL_ECT_LECTURER_ECT_COURSE_FROM_ECT_LECTURER_TITLE',
  'id_name' => 'ect_lecturer_ect_courseect_lecturer_ida',
);
$dictionary["ECT_Course"]["fields"]["ect_lecturer_ect_course_name"] = array (
  'name' => 'ect_lecturer_ect_course_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_ECT_LECTURER_ECT_COURSE_FROM_ECT_LECTURER_TITLE',
  'save' => true,
  'id_name' => 'ect_lecturer_ect_courseect_lecturer_ida',
  'link' => 'ect_lecturer_ect_course',
  'table' => 'ect_lecturer',
  'module' => 'ECT_Lecturer',
  'rname' => 'name',
);
$dictionary["ECT_Course"]["fields"]["ect_lecturer_ect_courseect_lecturer_ida"] = array (
  'name' => 'ect_lecturer_ect_courseect_lecturer_ida',
  'type' => 'link',
  'relationship' => 'ect_lecturer_ect_course',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_ECT_LECTURER_ECT_COURSE_FROM_ECT_COURSE_TITLE',
);

?>