<?php


if (!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

class GetSetStudentPayment
{
    public function updatePaymentOwed($bean, $event, $arguments)
    {
        // Kiểm tra xem module hiện tại là "ECT_Class"
        if ($bean->module_name === 'ECT_Payment') {
            $relatedStudent = $bean->get_linked_beans('ect_student_ect_payment', 'ECT_Student');
            if (!empty($relatedStudent)) {
                $studentPayment = $relatedStudent[0]->student_payment;
                $bean->payment_owed = $studentPayment;
            }
        }
    }
}