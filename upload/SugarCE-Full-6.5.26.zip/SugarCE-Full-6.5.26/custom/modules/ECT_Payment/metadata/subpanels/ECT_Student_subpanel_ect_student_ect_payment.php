<?php
// created: 2023-07-11 12:30:12
$subpanel_layout['list_fields'] = array (
  'name' => 
  array (
    'vname' => 'LBL_NAME',
    'widget_class' => 'SubPanelDetailViewLink',
    'width' => '45%',
    'default' => true,
  ),
  'ect_student_ect_payment_name' => 
  array (
    'type' => 'relate',
    'link' => true,
    'vname' => 'LBL_ECT_STUDENT_ECT_PAYMENT_FROM_ECT_STUDENT_TITLE',
    'id' => 'ECT_STUDENT_ECT_PAYMENTECT_STUDENT_IDA',
    'width' => '10%',
    'default' => true,
    'widget_class' => 'SubPanelDetailViewLink',
    'target_module' => 'ECT_Student',
    'target_record_key' => 'ect_student_ect_paymentect_student_ida',
  ),
  'payment_startdate' => 
  array (
    'type' => 'date',
    'vname' => 'LBL_PAYMENT_STARTDATE',
    'width' => '10%',
    'default' => true,
  ),
  'payment_deadline' => 
  array (
    'type' => 'date',
    'vname' => 'LBL_PAYMENT_DEADLINE',
    'width' => '10%',
    'default' => true,
  ),
  'payment_owed' => 
  array (
    'type' => 'int',
    'vname' => 'LBL_PAYMENT_OWED',
    'width' => '10%',
    'default' => true,
  ),
  'payment_status' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'vname' => 'LBL_PAYMENT_STATUS',
    'width' => '10%',
  ),
  'edit_button' => 
  array (
    'vname' => 'LBL_EDIT_BUTTON',
    'widget_class' => 'SubPanelEditButton',
    'module' => 'ECT_Payment',
    'width' => '4%',
    'default' => true,
  ),
  'remove_button' => 
  array (
    'vname' => 'LBL_REMOVE',
    'widget_class' => 'SubPanelRemoveButton',
    'module' => 'ECT_Payment',
    'width' => '5%',
    'default' => true,
  ),
);