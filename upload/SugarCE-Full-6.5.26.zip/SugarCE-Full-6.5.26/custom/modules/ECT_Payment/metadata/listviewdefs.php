<?php
$module_name = 'ECT_Payment';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'ECT_STUDENT_ECT_PAYMENT_NAME' => 
  array (
    'type' => 'relate',
    'link' => true,
    'label' => 'LBL_ECT_STUDENT_ECT_PAYMENT_FROM_ECT_STUDENT_TITLE',
    'id' => 'ECT_STUDENT_ECT_PAYMENTECT_STUDENT_IDA',
    'width' => '10%',
    'default' => true,
  ),
  'PAYMENT_STARTDATE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_PAYMENT_STARTDATE',
    'width' => '10%',
    'default' => true,
  ),
  'PAYMENT_DEADLINE' => 
  array (
    'type' => 'date',
    'label' => 'LBL_PAYMENT_DEADLINE',
    'width' => '10%',
    'default' => true,
  ),
  'PAYMENT_OWED' => 
  array (
    'type' => 'int',
    'label' => 'LBL_PAYMENT_OWED',
    'width' => '10%',
    'default' => true,
  ),
  'PAYMENT_STATUS' => 
  array (
    'type' => 'enum',
    'default' => true,
    'studio' => 'visible',
    'label' => 'LBL_PAYMENT_STATUS',
    'width' => '10%',
  ),
  'ASSIGNED_USER_NAME' => 
  array (
    'width' => '9%',
    'label' => 'LBL_ASSIGNED_TO_NAME',
    'module' => 'Employees',
    'id' => 'ASSIGNED_USER_ID',
    'default' => true,
  ),
);
?>
