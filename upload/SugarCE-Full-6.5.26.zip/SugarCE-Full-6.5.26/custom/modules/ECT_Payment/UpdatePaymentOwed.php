<?php

class UpdatePaymentOwed
{
    public function updateNewPaymentOwed($bean, $event, $arguments)
    {
        // Kiểm tra xem module hiện tại là "ECT_Payment"
        if ($bean->module_name === 'ECT_Payment') {
            // Lấy giá trị hiện tại của payment_total từ cơ sở dữ liệu
            $query = "SELECT payment_total FROM ect_payment WHERE name = '{$bean->name}'";
            $result = $GLOBALS['db']->query($query);
            if ($result && $GLOBALS['db']->getRowCount($result) > 0) {
                $row = $GLOBALS['db']->fetchByAssoc($result);
                $currentPayment = $row['payment_total'];
                $remainingPayment = $row['payment_remaining'];
                // Lấy giá trị hiện tại của payment_paytuition
                $currentTotalPayment = $bean->payment_paytuition;

                // Tính toán tổng giá trị của payment_paytuition và payment_total
                $newPayment = ($currentPayment + $currentTotalPayment);
                $bean->payment_total = $newPayment;
                $bean->payment_remaining = $remainingPayment - $newPayment;
                // Lưu giá trị vào cơ sở dữ liệu
//                $query = "UPDATE ect_payment SET payment_total = '".$newPayment."' WHERE name = '{$bean->name}'";
//                $GLOBALS['db']->query($query);
            } else {
                // Xử lý lỗi khi không tìm thấy giá trị trong cơ sở dữ liệu
                // Ghi log, hiển thị thông báo, hoặc thực hiện các hành động phù hợp
                // Ví dụ:
                // error_log('Không tìm thấy giá trị payment_total trong cơ sở dữ liệu');
                // echo 'Lỗi: Không tìm thấy giá trị payment_total trong cơ sở dữ liệu';
            }
        }
    }
}
