<?php

$hook_version = 1;
$hook_array = array();

$hook_array['before_save'] = array();

// Hook cho class AssignCourseID
$hook_array['before_save'][] = array(
    1,
    'ECT_Payment',
    'custom/modules/ECT_Payment/AssignCourseID.php',
    'AssignCourseID',
    'generateAndAssignCode'
);

// Hook cho class AssignPaymentID
$hook_array['before_save'][] = array(
    10,
    'ECT_Payment',
    'custom/modules/ECT_Payment/AssignPaymentID.php',
    'AssignPaymentID',
    'generateAndAssignCode'
);

// Hook cho class GetSetStudentPayment
$hook_array['before_save'][] = array(
    20,
    'ECT_Payment',
    'custom/modules/ECT_Payment/GetSetStudentPayment.php',
    'GetSetStudentPayment',
    'updatePaymentOwed'
);

// Hook cho class UpdatePaymentOwed
$hook_array['before_save'][] = array(
    30,
    'ECT_Payment',
    'custom/modules/ECT_Payment/UpdatePaymentOwed.php',
    'UpdatePaymentOwed',
    'updateNewPaymentOwed'
);

// Hook cho class UpdateStartDatePayment
$hook_array['before_save'][] = array(
    40,
    'ECT_Payment',
    'custom/modules/ECT_Payment/UpdateStartDatePayment.php',
    'UpdateStartDatePayment',
    'updatePayment'
);
