<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ect_class_ect_studentMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ect_course_ect_classMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ect_course_ect_lecturerMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ect_course_ect_student_1MetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ect_lecturer_ect_courseMetaData.php');


 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ect_student_ect_paymentMetaData.php');


?>