<?php 
 //WARNING: The contents of this file are auto-generated

 
 //WARNING: The contents of this file are auto-generated
$beanList['ECT_Class'] = 'ECT_Class';
$beanFiles['ECT_Class'] = 'modules/ECT_Class/ECT_Class.php';
$moduleList[] = 'ECT_Class';
$beanList['ECT_Course'] = 'ECT_Course';
$beanFiles['ECT_Course'] = 'modules/ECT_Course/ECT_Course.php';
$moduleList[] = 'ECT_Course';
$beanList['ECT_Lecturer'] = 'ECT_Lecturer';
$beanFiles['ECT_Lecturer'] = 'modules/ECT_Lecturer/ECT_Lecturer.php';
$moduleList[] = 'ECT_Lecturer';
$beanList['ECT_Payment'] = 'ECT_Payment';
$beanFiles['ECT_Payment'] = 'modules/ECT_Payment/ECT_Payment.php';
$moduleList[] = 'ECT_Payment';
$beanList['ECT_Student'] = 'ECT_Student';
$beanFiles['ECT_Student'] = 'modules/ECT_Student/ECT_Student.php';
$moduleList[] = 'ECT_Student';


?>