<?php
//auto-generated file DO NOT EDIT
$layout_defs['ECT_Course']['subpanel_setup']['ect_course_ect_lecturer']['override_subpanel_name'] = 'ECT_Course_subpanel_ect_course_ect_lecturer';
?>