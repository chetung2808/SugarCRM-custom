<?php
// created: 2023-07-11 12:36:52
$dictionary["ECT_Course"]["fields"]["ect_course_ect_lecturer"] = array (
  'name' => 'ect_course_ect_lecturer',
  'type' => 'link',
  'relationship' => 'ect_course_ect_lecturer',
  'source' => 'non-db',
  'module' => 'ECT_Lecturer',
  'bean_name' => 'ECT_Lecturer',
  'side' => 'right',
  'vname' => 'LBL_ECT_COURSE_ECT_LECTURER_FROM_ECT_LECTURER_TITLE',
);
