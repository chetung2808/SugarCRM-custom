<?php
// created: 2023-07-11 12:14:47
$dictionary["ECT_Course"]["fields"]["ect_course_ect_student_1"] = array (
  'name' => 'ect_course_ect_student_1',
  'type' => 'link',
  'relationship' => 'ect_course_ect_student_1',
  'source' => 'non-db',
  'module' => 'ECT_Student',
  'bean_name' => 'ECT_Student',
  'side' => 'right',
  'vname' => 'LBL_ECT_COURSE_ECT_STUDENT_1_FROM_ECT_STUDENT_TITLE',
);
