<?php
//auto-generated file DO NOT EDIT
$layout_defs['ECT_Class']['subpanel_setup']['ect_class_ect_student']['override_subpanel_name'] = 'ECT_Class_subpanel_ect_class_ect_student';
?>