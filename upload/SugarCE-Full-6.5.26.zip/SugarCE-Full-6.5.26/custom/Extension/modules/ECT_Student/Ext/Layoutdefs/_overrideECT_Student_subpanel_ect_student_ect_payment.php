<?php
//auto-generated file DO NOT EDIT
$layout_defs['ECT_Student']['subpanel_setup']['ect_student_ect_payment']['override_subpanel_name'] = 'ECT_Student_subpanel_ect_student_ect_payment';
?>