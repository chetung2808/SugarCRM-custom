<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ect_class_ect_studentMetaData.php');

?>