<?php 
 //WARNING: The contents of this file are auto-generated
include('custom/metadata/ect_course_ect_student_1MetaData.php');

?>