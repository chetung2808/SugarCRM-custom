<?php
/***CONFIGURATOR***/
$sugar_config['default_currency_iso4217'] = 'VND';
$sugar_config['default_currency_name'] = 'Vietnam Dong';
$sugar_config['default_currency_symbol'] = 'VND';
$sugar_config['default_date_format'] = 'd-m-Y';
$sugar_config['default_time_format'] = 'H:i';
/***CONFIGURATOR***/